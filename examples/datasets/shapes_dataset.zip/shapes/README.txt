Toy shapes dataset for MOSAIC EDA. Classes are folder names.

Synthetic shapes with an annotation table, for MOSAIC EDA group mode.

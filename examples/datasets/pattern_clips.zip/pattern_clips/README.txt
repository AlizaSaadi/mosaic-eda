Synthetic pattern clips for MOSAIC EDA. Folders are labels.

Toy speech commands dataset for MOSAIC EDA. Labels are folders.
